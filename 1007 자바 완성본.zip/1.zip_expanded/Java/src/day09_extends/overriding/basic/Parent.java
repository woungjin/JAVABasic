package day09_extends.overriding.basic;

public class Parent {

	void method01() {
		System.out.println("부모의 1번 메소드 실행");
	}
	
	void method02() {
		System.out.println("부모의 2번 메소드 실행");
	}
	
	
}
