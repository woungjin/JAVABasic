package day09_extends.overriding.basic;

public class Child extends Parent {

	// 오버라이딩 : 부모 클래스 한테 물려받은 메소드를 내용물을 바꿔서 재정의 

	void method02() {
		System.out.println("자식의 3번 메소드 실행");
	}

	
}
