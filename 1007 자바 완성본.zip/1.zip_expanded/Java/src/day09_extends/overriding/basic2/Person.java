package day09_extends.overriding.basic2;

public class Person {
	String name ;
	int age;

	
	String info() {
		return "이름 : " + name + ", 나이 : " + age ;
	}
}
