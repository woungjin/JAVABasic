package day09_extends.overloading.basic;

public class MainClass {
	public static void main(String[] args) {
		
		Basic b = new Basic();
		b.input("1");
		
		
	}
}
