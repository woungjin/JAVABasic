package day09_extends.inherit.bad;

public class Student extends Person {
	
	String studentid;
}
