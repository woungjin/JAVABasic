package day09_extends.inherit.bad;

public class Teacher extends Person{
		String subject;
		


}
