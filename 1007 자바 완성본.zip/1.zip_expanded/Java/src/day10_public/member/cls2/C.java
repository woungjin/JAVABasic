package day10_public.member.cls2;

import day10_public.member.cls.A;

public class C {
	
//	public c () {
//		A a = new A(;
//		a.var1 = 1;
//		a.var2 = 1; // deafult(x);  = 같은패키지내 다른 클래스에서 사용가능
//		a.var3 = 1; // private(x); 	= 다른패키지 다른 클래스는 사용불가 
//		a.method1(); // public
//		a.method2(); // default(x);
//		a.method3(); // private;
	}
