package day10_public.member.cls;

public class A {

	public int var1;
	int var2;
	private int var3;
	
	public void method1() {}
	void method2() {}
	private void method3() {}
	
	
}
