package day10_public.modi.cls.pac2;

public class C {

}
