package day10_public.modi.cls.pac1;

public class A {

	// 생성자 
	public A(int i) {}
	A(boolean b) {} // default
	private A(String s) {}
	
	
}
