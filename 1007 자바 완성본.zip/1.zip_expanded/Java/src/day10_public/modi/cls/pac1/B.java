package day10_public.modi.cls.pac1;

// 클래스에 붙는 접근제어자는 public , default 밖에 없습니다
// default -접근 제어자를 붙이지 않는 형태 
public class B {
	
}
