package day10_public.modi.protected_;

public class B {

	int a;
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public B () {
		A a = new A() ;
		a.bool= true;
		a.method();
		

		
		
		
	}
}
