package day10_public.modi.protected_;

public class A {
	
	protected boolean bool;
	
	protected A() {
		
	}
	protected void method() {
		
	}

}
