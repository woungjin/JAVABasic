package day10_public.poly;

public class Parent {

	public void method1() {
		System.out.println("부모의 1번 메소드 실행");
	}
	public void method2() {
		System.out.println("부모의 2번 메소드 실행");
	}
	
	
	
}
