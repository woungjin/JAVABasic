package day10_public.poly;

public class Child extends Parent{
	

	public void method2() {
		System.out.println("자식의 2번 메소드 실행");
	}
	
	public void method3() {
		System.out.println("자식의 3번 메소드 실행");
	}
	
}
