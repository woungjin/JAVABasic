package day16_api.anonymous.basic02;

public interface RemoteControl {
	public void turnOn(); // 켜다
	public void turnoff(); // 끄다
	public void volumeUp(); // 소리 켜다
	public void volumeDown(); // 소리를 끄다 
}
