package day16_api.ramda.basic01;

// 함수적 인터페이스란 - 구현해야하는 추상 메소드가 무조건 1개인 인터페이스 
public interface Say01 {

	public void talking();

}
