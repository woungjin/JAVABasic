package day16_api.ramda.basic01;

public interface Say02 {
	public void talking(String word);
	
}
