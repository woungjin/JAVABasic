package day16_api.ramda.basic01;

public interface Say03 {
	// return 형이 있는 람다

	public String talking();

}
