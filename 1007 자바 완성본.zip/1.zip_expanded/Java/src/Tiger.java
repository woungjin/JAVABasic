public class Tiger extends Animal {
	Tiger(String name , int age) {
		super(name,age);
	}
}
