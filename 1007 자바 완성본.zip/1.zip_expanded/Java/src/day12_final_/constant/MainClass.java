package day12_final_.constant;

public class MainClass {

	public static void main(String[] args) {
		
		System.out.println(Const.EARTH_RADIUS);;
		System.out.println("산소" + Const.O2);
		System.out.println("원주율 " + Const.PI);
		System.out.println(Math.PI);

		
		
	}

}
