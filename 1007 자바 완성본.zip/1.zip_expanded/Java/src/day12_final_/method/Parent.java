package day12_final_.method;

public/* final */class Parent { // 클래스에 final이 붙으면 상속이 불가능해 진다 

	public void method1() {} 
	public final void method2() {}// 메소드에 final이 붙으면 오버라이딩이 금지된다 
	
	
}
