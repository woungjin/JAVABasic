package day12_final_.method;

public class Child extends Parent{ // final class를 만들일은 없을것 
	 
	@Override
	public void method1() {
		// TODO Auto-generated method stub
		super.method1();
	}
	/*
	 * //public void method2() { super.method2(); }
	 */
}
