package day02;

public class OperatorEx02 {

	public static void main(String[] args) {

		// 2항 연산자

		int i = 7 / 3; // i = 2
		int j = 7 % 3; // 1
		int k = 7 * 3; // 21

		// 비교 연산자
		System.out.println(i == j); // false
		System.out.println(i != j); // true
		System.out.println(i >= j); // true
		System.out.println(i < j); // false
		System.out.println(k != 21); // false
		System.out.println(k % 2 != 0); // true
		System.out.println(k % 2 == 1); // true

		// 비트 연산자
		int a = 5;
		int b = 3;
	}

}
