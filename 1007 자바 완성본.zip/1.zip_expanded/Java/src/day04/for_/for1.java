package day04.for_;

public class for1 {

	public static void main(String[] args) {
	
		// 10 ~ 1 합  
		
		for (int i=10; i>0; i--) {
			System.out.println(i);
		}
		
		
	}

}
