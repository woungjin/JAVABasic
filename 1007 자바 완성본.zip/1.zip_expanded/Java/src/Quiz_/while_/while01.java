package Quiz_.while_;


public class while01 {

	public static void main(String[] args) {


		String[] arr =new String[100];
		
		if(arr[0].equals(null)) {
			System.out.println("!");
		}
	}

}
