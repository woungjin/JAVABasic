package Quiz_.for_;

public class MultiFor2 {

	public static void main(String[] args) {
		
		for(int i =1 ; i<=9;i+=3) {
			for(int j=1; j<=9;j++) {
				System.out.printf("\t%d x %d = %d \t %d x %d = %d\t %d x %d = %d \n ",i,j,i*j,i+1);

			}
				System.out.println("");
		}
		
		
		
	}
}
