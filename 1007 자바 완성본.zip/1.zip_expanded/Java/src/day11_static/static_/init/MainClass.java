package day11_static.static_.init;

public class MainClass {

	public static void main(String[] args) {
		
		Computer c1 = new Computer(1000);
		System.out.println(Computer.company);
		Computer c2 = new Computer(1000);
		Computer c3 = new Computer(1000);

	}

}
