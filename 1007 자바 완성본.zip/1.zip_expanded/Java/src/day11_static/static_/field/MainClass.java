//package day11_static.static_.field;
//
//public class MainClass {
//	
//	public static void main(String[] args) {
//		
//		Count c1 = new Count();
//		
//		c1.a++;
//		c1.b++;
//		System.out.println(c1.a);
//		System.out.println(c1.b);
//		
//		
//		Count c2 = new Count();
//		c2.a++;
//		c2.b++;
//		
//		System.out.println("일반멤버변수 : " + c2.a);
//		System.out.println("정적: " + c2.b);
//		
//		Count c3 = new Count();
//		c3.a++;
//		c3.b++;
//		
//		
//		// static은 클래스 밖에 1개만 생성된다 , 객체들간 서로 공유하며 사용함
//		// 객체 생성없이 바로 "클래스.static"으로 사용 한다 
//	
//
//	
//	}
//	
//}
