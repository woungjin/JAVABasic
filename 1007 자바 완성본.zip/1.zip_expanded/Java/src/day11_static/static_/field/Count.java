package day11_static.static_.field;

public class Count {
	
	public int a ; //일반 멤버 변수
	public static int b ; // 정적 멤버 변수 == static 
	
	
	
	
}
