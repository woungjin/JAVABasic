package day17_thread.runable;

public class VoteThreadMainClass {

	public static void main(String[] args) {
		
		

	}

}
