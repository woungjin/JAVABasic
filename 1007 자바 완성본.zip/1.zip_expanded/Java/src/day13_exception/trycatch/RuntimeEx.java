package day13_exception.trycatch;

public class RuntimeEx {
	
	public static void main(String[] args) {
		
		// 실행 예외 
		// 1. ArrayIndex 
		int[] arr = {1,2,3,4,5};
		System.out.println(arr[4]);
		
		
		// 2. Classcasting
		// String s = (String)new Object();
		
		// NumberFormat
//		String s = "10-";
//		int num = Integer.parseInt(s);
//		System.out.println(num);
		

	}
}
