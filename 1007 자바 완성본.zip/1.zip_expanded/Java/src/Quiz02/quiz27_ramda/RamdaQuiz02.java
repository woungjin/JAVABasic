package Quiz02.quiz27_ramda;

public class RamdaQuiz02 {

	public static void main(String[] args) {

		
		// 1. BufferedReader로 파일을 읽고
		// 2. 수출입구분 "수출" 항목의 "오징어"가 포함되어 있는 데이터만 구분해서
		// 		해당 데이터의 총합계를 구해보세요

	}

}
