package Quiz02.quiz14_instanceof;

public class Player {

	String name;
	int hp;
	int mp;
	
	void info() {
		System.out.println("캐릭명 : " + name);
		System.out.println("체력 : " + hp);
		System.out.println("마나 : " + mp);
		
	}
		
	
}
