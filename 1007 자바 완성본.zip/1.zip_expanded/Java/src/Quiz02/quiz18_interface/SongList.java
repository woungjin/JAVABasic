package Quiz02.quiz18_interface;


public interface SongList {

	public void insertList(String song);
	public void playList();
	public int playLength();
}
