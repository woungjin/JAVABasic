package Quiz02.quiz26_stream;

public class Data {
	private String city;
	private String m;
	private int year;
	private int month;
	private int money;
	public Data(String city, String m, int year, int month, int money) {
		super();
		this.city = city;
		this.m = m;
		this.year = year;
		this.month = month;
		this.money = money;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getM() {
		return m;
	}
	public void setM(String m) {
		this.m = m;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
public Data() {
	// TODO Auto-generated constructor stub
}
	
	
}
