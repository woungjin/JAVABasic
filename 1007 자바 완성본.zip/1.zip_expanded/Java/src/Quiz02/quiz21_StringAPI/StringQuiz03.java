package Quiz02.quiz21_StringAPI;

public class StringQuiz03 {

	public static void main(String[] args) {

		System.out.println();
		
	}

}
