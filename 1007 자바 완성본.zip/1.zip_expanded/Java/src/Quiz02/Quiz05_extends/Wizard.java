package Quiz02.Quiz05_extends;

public class Wizard extends Player{

	void iceArrow() {
		System.out.println("얼음 화살 사용 ");
	}
	
}
