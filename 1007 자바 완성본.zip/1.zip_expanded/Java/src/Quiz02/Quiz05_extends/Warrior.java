package Quiz02.Quiz05_extends;

public class Warrior extends Player{

	void bash() {
		System.out.println("때리기 스킬 사용");
	}
	
}
