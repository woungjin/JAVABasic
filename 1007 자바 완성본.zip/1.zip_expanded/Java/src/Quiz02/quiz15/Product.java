package Quiz02.quiz15;

public class Product {

	public int price;
	public String name;
	
	public Product(int price, String name) {
		super();
		this.price = price;
		this.name = name;
	}

	
	
}
