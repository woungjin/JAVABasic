package Quiz02.quiz15;

public class Tv extends Product {

	public Tv (int price, String name) {
		super(price, name);
	}
	
}
