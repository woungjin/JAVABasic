package Quiz02.quiz15;

public class Computer extends Product {


	public Computer(int price , String name) {
		super(price, name);
	}
	
	
	
}
