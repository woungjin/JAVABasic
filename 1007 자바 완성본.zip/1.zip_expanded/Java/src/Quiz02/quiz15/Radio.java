package Quiz02.quiz15;

public class Radio extends Product{
	
	public Radio (int price, String name) {
		super(price, name);
	}
}
