package Quiz02.quiz12_getter_setter;

public class MainClass {
		public static void main(String[] args) {
			
			Computer com = new Computer();
			com.getMonitor().info();
			com.computerInfo();
			com.getKeyboard().info();
			
			
		}
}
