package Quiz02.quiz06_over;

public class a {

}
