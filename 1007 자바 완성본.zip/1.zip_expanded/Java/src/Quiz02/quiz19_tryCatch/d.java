package Quiz02.quiz19_tryCatch;

public class d {

}
