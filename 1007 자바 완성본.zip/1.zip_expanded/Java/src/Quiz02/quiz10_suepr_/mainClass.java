package Quiz02.quiz10_suepr_;

public class mainClass {
	public static void main(String[] args) {
		
		MyCart1 my = new MyCart1(1200);
		
		for(int i = 0 ; i <=10 ; i++ ) {
			my.buy("tv");
		}

	}
}
