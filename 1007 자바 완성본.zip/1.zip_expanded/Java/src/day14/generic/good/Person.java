package day14.generic.good;

public class Person {

}
