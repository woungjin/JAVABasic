package day14.generic.good;

public class ABC<T> { // 제너릭 클래스
	
	private T t ;

	public T getT() {
		return t;
	}

	public void setT(T t) {
		this.t = t;
	}

}
