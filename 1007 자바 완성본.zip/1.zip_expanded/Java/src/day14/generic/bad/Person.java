 package day14.generic.bad;

public class Person {
	
	

}
