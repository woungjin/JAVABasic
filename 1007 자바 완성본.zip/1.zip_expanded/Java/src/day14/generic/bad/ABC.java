package day14.generic.bad;


// generic이 없었을 때의 문제점 
public class ABC {
	
	private Object obj;

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}
	
	
	
}
