package day08_Class.fruit;

public class Apple {

}
