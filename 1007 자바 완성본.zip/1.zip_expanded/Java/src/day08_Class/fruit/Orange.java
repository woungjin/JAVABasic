package day08_Class.fruit;

public class Orange {

}
