package day08_Class;

public class Calculator {
	
	int result = 0;

	int add(int n) {
		result += n;
		return result;
	}
}
