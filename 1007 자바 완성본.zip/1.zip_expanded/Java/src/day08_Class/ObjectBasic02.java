package day08_Class;

public class ObjectBasic02 {

	public static void main(String[] args) {
		// 클래스를 이용한 방식
		
		System.out.println("----1번 계산기----");
		
		Calculator cal = new Calculator();

		
	}

	
	
	
}
 