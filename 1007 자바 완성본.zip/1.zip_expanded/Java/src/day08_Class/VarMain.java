package day08_Class;

public class VarMain {

	public static void main(String[] args) {
		
		Variable var = new Variable();
		
		var.a = 100;
		var.printNum(10);
		
	}
	
}
