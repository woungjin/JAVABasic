package day08_Class.com.def;

public class DEF {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
