package day08_Class.com.abc;

public class ABC {

	public static void main(String[] args) {
		

	}

}
