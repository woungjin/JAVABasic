package day05;

import java.util.Scanner;

public class Break2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		while (true) {
			System.out.println("5 x 3 == ? ");
			System.out.print(": ");
			 
			int answer = sc.nextInt();
		}

		
		
		
		
	}

}
