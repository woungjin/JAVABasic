package day01;

public class VariableEx {

	public static void main(String[] args) {
		
		/*
				＊ 변수
				
				- 생성 :  <타입> 이름;
				
				- 
				
		 */
		
		int num;
		int num2 = 20;
		System.out.println(num2);
		
		
		String str = "1";
		
		// 타입이 다르면 바로저장 x
//		int num3 = str;
		
		System.out.println("---------------");
		
		int result = num2+20;
		int result3 = 100;
		result3 =50;
		result3 =result;
		result3 = 100;
		
	}
}
