package day01;

public class variableScope {

	public static void main(String[] args) {
		//변수의 범위
		
		int num1 = 10, num2= 20;
		
		if(true) {
			int num3 = 30;
		}
		
		

	}

}
