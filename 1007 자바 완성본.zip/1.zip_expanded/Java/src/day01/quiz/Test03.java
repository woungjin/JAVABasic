package day01.quiz;

public class Test03 {
	public static void main(String[] args) {
		

		// A~Z 까지 반복문을 통해서 문자열을 붙여서 출력
		for (int i = 65; i < 91; i++) {
			System.out.printf("%c", i);
		}
	}
}
