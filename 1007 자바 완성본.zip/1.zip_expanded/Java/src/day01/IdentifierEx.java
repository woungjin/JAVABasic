package day01;

public class IdentifierEx {

	public static void main(String[] args) {

		// 식별자 : 변수 , 메소드, 클래스등 이름을 구별하는것 
		int age = 20;
		int Age = 21;
		
		System.out.println(age);
		System.out.println(Age);

		int phoneNumber = 4;
//		int phone number = 5;
		
//		int class =1; -> 키워드x

	
	}
}
