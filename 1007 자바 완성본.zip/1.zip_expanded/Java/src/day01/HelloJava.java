package day01;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Quiz02.quiz26_stream.Data;

public class HelloJava {

	public static void main(String[] args) {

		
		for(int i = 0 ; i<3; i++) {
		int	sum= 1 ; 
			System.out.println(i);
			
		}
		

	}

}
