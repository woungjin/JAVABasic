package day12_abs_inter.bad;

public class HeadStore {
	// 부모 클래스에 명시된 메소드는 반드시 자식클래스에서 각각 오버라이딩 해야합니다.
	public void apple( ) {
		System.out.println("각 지점에서 가격을 제시하세요");
	}
	
	public void banana() {
		System.out.println("각 지점에서 가격을 제시하세요 ");
	}
	
	public void melon() {
		System.out.println("각 지점에서 가격을 제시하세요");
	}
	
	public void orange() {
		System.out.println("각 지점에서 가격을 제시하세요");
	}
	
	
	
}
