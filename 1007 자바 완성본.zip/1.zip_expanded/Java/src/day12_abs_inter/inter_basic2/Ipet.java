package day12_abs_inter.inter_basic2;

public interface Ipet {
	
	public void Play();
	
}
