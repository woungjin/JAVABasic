package day12_abs_inter.inter_basic2;

public class Tiger extends Animal{
	
	
	
	@Override
	public void eat() {
		System.out.println("고기 먹는다 고기");
		
	}
}
