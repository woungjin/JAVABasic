package day12_abs_inter.inter_basic2;

public class Shark extends Fish {
	@Override
	public void swim() {
		System.out.println("상어가 헤엄칩니다");

	}
}
