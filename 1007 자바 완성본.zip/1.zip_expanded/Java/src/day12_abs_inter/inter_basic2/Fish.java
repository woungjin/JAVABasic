package day12_abs_inter.inter_basic2;

public abstract class Fish {
	
	public abstract void swim();
	
	
}
