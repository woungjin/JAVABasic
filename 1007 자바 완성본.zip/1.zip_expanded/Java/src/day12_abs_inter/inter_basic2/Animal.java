package day12_abs_inter.inter_basic2;

public abstract class Animal {

	public abstract void eat();
}
