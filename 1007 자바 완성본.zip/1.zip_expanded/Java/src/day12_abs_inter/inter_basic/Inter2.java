package day12_abs_inter.inter_basic;

public interface Inter2 {
	
	int ABC = 2 ;

	void method2();
}
