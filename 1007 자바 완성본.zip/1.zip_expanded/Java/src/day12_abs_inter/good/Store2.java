package day12_abs_inter.good;

public class Store2 extends HeadStore{

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return super.getName();
	}

	@Override
	public void apple() {
		System.out.println("1");
		
	}

	@Override
	public void banana() {
		System.out.println("2");
		
	}

	@Override
	public void orange() {
		System.out.println("3");
		
	}

	public void melon() {
		System.out.println("4");
	}
	
	
}
