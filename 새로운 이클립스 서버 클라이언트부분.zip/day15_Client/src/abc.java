
public class abc {

	public static void main(String[] args) {
		
		abc a = new abc();
		String b = a.sayNick("홍길동", 10);
		System.out.println(b);
		

	}

	public String sayNick(String name, int index) {
		
		String[] arr = {"박장군", "김원장" , "진회장","김재명"};

		int ran = (int) (Math.random()*index); 
		try {
			return name + "별명은:"+arr[ran]+"입니다";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return name + "별명은:"+arr[ran]+"입니다";
		
	}
	
}
