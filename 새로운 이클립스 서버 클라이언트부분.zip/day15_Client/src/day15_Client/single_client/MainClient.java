package day15_Client.single_client;

import java.net.Socket;

public class MainClient {

	public static void main(String[] args) {
	
		try {
			Socket socket = new Socket("192.168.104.55",8383);
			
			
			// 메세지 전송 클래스
			Sender sender = new Sender(socket);
			
			// 메세지 수신 클래스
			Receive receive = new Receive(socket);
			
			sender.start();			
			receive.start();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
