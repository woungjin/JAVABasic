package multi_client;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.regex.Pattern;

public class Receive extends Thread {

	private Socket socket;

	public Receive(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			InputStream is = socket.getInputStream();
			BufferedReader bf = new BufferedReader(new InputStreamReader(is, "UTF-8"));

			while (true) {

				String message = bf.readLine();
				// 추가 : 메시지를 받아 왔을 때 , 자신이라면 콘솔창에서 출력하지 않는 코드를 작성
				// 서버로부터 받은 message를 > 기반으로 자르고 id부분이 userId와 같다면 출력부분은 생략
				
				String[] split = message.split(">");
				if(split.length == 2 && split[0].equals(MainClient.userID)) {
					continue;
				}
				
				System.out.println("상대로부터 온 메세지 : " + message);
				
				
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
