package multi_client.copy;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ㅁ {
	public static Map< Integer,String> map = new HashMap<>();
	public static void main(String[] args) {
		
//		String message = "/w gdgd hi";
//		String[] arr = message.split("w",2);
//		int begin = message.indexOf(" ")+1;
//		int end = message.indexOf(" ",begin);
//		System.out.println(end);
//		
//		
//		if(end!=-1){
//			System.out.println();
//			String id = message.substring(begin,end);
//			System.out.println(id);
//			String msg = message.substring(end+1);
//
//			System.out.println(id);
//			
//		}

		map.put("abc", 55555);
		map.put("bb", 123);
		for(String a : map.values()) {
			System.out.println();
			
			
		}
//		
		
		
	}

}
