package multi_client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.regex.Pattern;

public class Sender extends Thread {

	// 생성자 
	
	private Socket socket;
	private String userID;
	
	public Sender(Socket socket) {
		this.socket = socket;
	}
	
	public void run() {
		try {
			// 사용자 한테 키보드를 통해 값을 입력받음
			BufferedReader bf = new BufferedReader(new InputStreamReader(System.in,"UTF-8"));
			
			// 추가 : 시작할 때 , 아이디를 입력받는 부분을 추가 
			System.out.println("ID: ");
			while(true) {
				String id = bf.readLine();
				
				// id가 null이 아니고 id가 동일하다면 재입력을 받는다 
				if(id == null || Pattern.compile(":").matcher(id).find()) {
					System.out.println("사용할수 없는 id입니다");
					System.out.println("닉네임");
					continue; // while문의 처음으로 
				} else {
					MainClient.userID = id; //아이디를 저장하고
					break;
				}
			}
		
			// printWriter을 쓰면 서버에 값을 보낸다 
			PrintWriter out = new PrintWriter( socket.getOutputStream());
			out.println("ID:" +MainClient.userID);
			out.flush();
			
			out.println(socket.getPort()+","+MainClient.userID);
			out.flush();
			while(true) {
				String message = bf.readLine();//사용자한테 받은 메세지 
				if(message.equals("/exit")) {
					break;
				}
				out.println(message); // ;out이 가리키는 소켓에 메세지 전달
				out.flush();	// 전송
				
			}
			out.close();
			bf.close();
			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.run();
	}
	
	
}
